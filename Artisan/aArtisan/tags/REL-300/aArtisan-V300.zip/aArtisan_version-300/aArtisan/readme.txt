aArtisan.ino
-------------

Release 3.00 15-April-2014
--------------------------------------
- tested and ready for release
- fixes intermittent Hottop controller resets due to fan current

Release 3RC1 for testing 13-April-2014
--------------------------------------
- changes baud rate to 115,200
- increases temperature output precision to 2 decimal places on serial port
- adds DCFAN command to address inrush current issues on some Hottop roasters

Jim Gallt
MLG Properties, LLC
